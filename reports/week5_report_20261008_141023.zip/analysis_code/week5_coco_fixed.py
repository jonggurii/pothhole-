"""COCO AP at the explicitly selected maxDets, without default-only summarize()."""
import contextlib, io
import numpy as np
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval


def evaluate(pred, rows, max_det=300):
    if len(pred)!=len(rows) or not rows: raise ValueError('Prediction/GT image counts must agree and be nonempty')
    if not isinstance(max_det,int) or max_det<=10: raise ValueError('max_det must be an integer >10')
    images=[{'id':i} for i in range(len(rows))]; cats=[{'id':1,'name':'pothole'}]
    ga=[]; da=[]
    for i,(p,r) in enumerate(zip(pred,rows)):
        gt=np.asarray(r['gt'],dtype=np.float64).reshape(-1,4)
        boxes=np.asarray(p['boxes'],dtype=np.float64).reshape(-1,4)
        scores=np.asarray(p['scores'],dtype=np.float64).reshape(-1)
        if len(boxes)!=len(scores) or not np.isfinite(scores).all(): raise ValueError('Bad prediction scores')
        for arr,target in [(gt,ga),(boxes,da)]:
            role='GT' if target is ga else 'prediction'
            image=r.get('path',r.get('image',f'image_index={i}'))
            if not np.isfinite(arr).all():
                bad=np.flatnonzero(~np.isfinite(arr).all(axis=1))
                raise ValueError(f'{role}: nonfinite bbox in {image}; indices={bad.tolist()}, boxes={arr[bad].tolist()}')
            wh=arr[:,2:]-arr[:,:2]
            bad=np.flatnonzero(np.any(wh<=0,axis=1) if target is ga else np.any(wh<0,axis=1))
            if len(bad):
                raise ValueError(f'{role}: invalid bbox geometry in {image}; indices={bad.tolist()}, boxes={arr[bad].tolist()}')
            # Finite zero-area predictions remain unmatched detections (FP) under COCO.
            # Do not silently remove them or change GT annotations.
            for j,b in enumerate(arr):
                x,y,x2,y2=map(float,b); w,h=x2-x,y2-y
                ann={'id':len(target)+1,'image_id':i,'category_id':1,'bbox':[x,y,w,h],'area':w*h,'iscrowd':0}
                if target is da: ann['score']=float(scores[j])
                target.append(ann)
    if not ga: raise ValueError('No ground truth; overall AP is undefined')
    with contextlib.redirect_stdout(io.StringIO()):
        gt=COCO(); gt.dataset={'images':images,'categories':cats,'annotations':ga,'info':{}}; gt.createIndex()
        dt=COCO(); dt.dataset={'images':images,'categories':cats,'annotations':da,'info':{}}; dt.createIndex()
        ev=COCOeval(gt,dt,'bbox'); ev.params.imgIds=list(range(len(rows))); ev.params.catIds=[1]
        ev.params.maxDets=[1,10,max_det]
        ev.evaluate(); ev.accumulate()
    # precision shape: IoU x recall x class x area x maxDets
    mi=ev.params.maxDets.index(max_det)
    def ap(area='all',iou=None):
        ai=ev.params.areaRngLbl.index(area)
        values=ev.eval['precision'][:,:,:,ai,mi]
        if iou is not None: values=values[np.isclose(ev.params.iouThrs,iou)]
        values=values[values>-1]
        return float(values.mean()) if values.size else -1.
    result={'map':ap(),'map_50':ap(iou=.5),'map_75':ap(iou=.75),
            'map_small':ap('small'),'map_medium':ap('medium'),'map_large':ap('large')}
    if any(not np.isfinite(result[k]) or not 0<=result[k]<=1 for k in ['map','map_50','map_75']):
        raise RuntimeError(f'Invalid overall COCO AP; refusing model selection: {result}')
    return result,ev


def map_metrics(pred,rows,cfg): return evaluate(pred,rows,int(cfg['max_det']))[0]


def select_alpha(trials):
    if not trials: raise ValueError('No alpha trials')
    for r in trials:
        if not np.isfinite(r['map']) or not 0<=r['map']<=1:
            raise ValueError(f'Invalid validation mAP; cannot select alpha: {r}')
    return max(trials,key=lambda x:(x['map'],-x['alpha']))


def self_test():
    b=np.array([[0.,0.,20.,20.]])
    p=[{'boxes':b,'scores':np.array([.9])}]; t=[{'gt':b}]
    for cap in [100,300]:
        m,ev=evaluate(p,t,cap); assert np.isclose(m['map'],1.) and np.isclose(m['map_50'],1.)
        with contextlib.redirect_stdout(io.StringIO()): ev.summarize()
        if cap==100: assert np.isclose(ev.stats[0],m['map'])
        elif ev.stats[0]==-1: print('Reproduced: default summarize returns -1 at maxDets=300; corrected AP=1.0')
    empty=[{'boxes':np.empty((0,4)),'scores':np.empty(0)}]
    assert evaluate(empty,t)[0]['map']==0
    # A high-score false positive before the true detection lowers AP.
    p2=[{'boxes':np.array([[30,30,50,50],[0,0,20,20]]),'scores':np.array([.95,.9])}]
    assert np.isclose(evaluate(p2,t)[0]['map'],.5)
    # Same prediction, IoU=.6: only .50/.55/.60 thresholds pass -> mAP=.3.
    p3=[{'boxes':np.array([[5,0,25,20]]),'scores':np.array([.9])}]
    assert np.isclose(evaluate(p3,t)[0]['map'],.3)
    assert select_alpha([{'alpha':0.,'map':.4},{'alpha':1.,'map':.6}])['alpha']==1.
    try: select_alpha([{'alpha':0.,'map':-1.}])
    except ValueError: pass
    else: raise AssertionError('Invalid AP must stop alpha selection')
    zero=[{'boxes':np.array([[10,10,10,20],[0,0,20,20]]),'scores':np.array([.95,.9])}]
    assert np.isclose(evaluate(zero,t)[0]['map'],.5)  # invalid-region detection still contributes FP
    assert evaluate([{'boxes':np.array([[10,10,10,20]]),'scores':np.array([.9])}],t)[0]['map']==0
    for bad_gt in [np.array([[0,0,0,20]]),np.array([[0,0,np.nan,20]])]:
        try: evaluate(p,[{'gt':bad_gt,'path':'bad_gt_image.jpg'}])
        except ValueError as exc: assert 'GT' in str(exc) and 'bad_gt_image.jpg' in str(exc)
        else: raise AssertionError('Invalid GT must not be removed')
    try: evaluate([{'boxes':np.array([[20,0,10,20]]),'scores':np.array([.9])}],t)
    except ValueError as exc: assert 'prediction' in str(exc)
    else: raise AssertionError('Reversed prediction must fail')
    print('PASS: AP100/AP300, empty detections, FP ordering, IoU averaging, zero-area prediction FP, GT diagnostic, invalid-AP guard')

if __name__=='__main__': self_test()
