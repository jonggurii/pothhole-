from pathlib import Path
import csv, hashlib, json, time
import cv2
import numpy as np
import torch
from torch import nn
from ultralytics import YOLO
from week5_coco_fixed import map_metrics, select_alpha
def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()

def ious(a, b):
    a=np.asarray(a, dtype=np.float32).reshape(-1,4)
    b=np.asarray(b, dtype=np.float32).reshape(-1,4)
    lo=np.maximum(a[:,None,:2], b[None,:,:2]); hi=np.minimum(a[:,None,2:], b[None,:,2:])
    inter=np.maximum(hi-lo,0).prod(2)
    aa=np.maximum(a[:,2:]-a[:,:2],0).prod(1)
    bb=np.maximum(b[:,2:]-b[:,:2],0).prod(1)
    return inter / np.maximum(aa[:,None]+bb[None,:]-inter, 1e-9)

class CropCNN(nn.Module):
    def __init__(self):
        super().__init__()
        blocks=[]; c=3
        for width in [32,64,128]:
            blocks += [nn.Conv2d(c,width,3,padding=1),nn.BatchNorm2d(width),nn.ReLU(),nn.MaxPool2d(2)]
            c=width
        self.net=nn.Sequential(*blocks,nn.AdaptiveAvgPool2d(1),nn.Flatten(),nn.Dropout(.2),nn.Linear(128,1))
    def forward(self,x): return self.net(x).flatten()

def crop_tensor(im,box,size):
    h,w=im.shape[:2]
    x1,y1=np.floor(box[:2]).astype(int); x2,y2=np.ceil(box[2:]).astype(int)
    x1,y1=max(0,min(x1,w-1)),max(0,min(y1,h-1))
    x2,y2=max(x1+1,min(x2,w)),max(y1+1,min(y2,h))
    crop=cv2.cvtColor(cv2.resize(im[y1:y2,x1:x2],(size,size)),cv2.COLOR_BGR2RGB)
    return torch.from_numpy(crop.transpose(2,0,1).copy()).float()/255.

@torch.inference_mode()
def cnn_scores(net,im,boxes,cfg):
    if len(boxes)==0: return np.empty(0,dtype=np.float32)
    result=[]
    for start in range(0,len(boxes),cfg['cnn_batch']):
        x=torch.stack([crop_tensor(im,b,cfg['crop_size']) for b in boxes[start:start+cfg['cnn_batch']]])
        result.append(net(x.to(cfg['torch_device'])).sigmoid().cpu().numpy())
    return np.concatenate(result)

def rescore(base,probs,alpha):
    return [{'boxes':p['boxes'],'scores':p['scores']*np.maximum(q,1e-8)**alpha} for p,q in zip(base,probs)]

def counts_at(pred,rows,threshold,iou=.5):
    result=[]
    for p,r in zip(pred,rows):
        idx=np.flatnonzero(p['scores']>=threshold)
        idx=idx[np.argsort(-p['scores'][idx],kind='stable')]
        overlap=ious(p['boxes'][idx],r['gt']); used=set(); tp=0
        for ov in overlap:
            eligible=[j for j in range(len(ov)) if j not in used and ov[j]>=iou]
            if eligible:
                j=max(eligible,key=lambda j:ov[j]); used.add(j); tp+=1
        result.append([tp,len(idx)-tp,len(r['gt'])-tp])
    return np.asarray(result,dtype=np.int64)

def operating_metrics(counts):
    tp,fp,fn=np.asarray(counts).sum(0)
    p=tp/max(tp+fp,1); r=tp/max(tp+fn,1)
    return {'precision':float(p),'recall':float(r),'f1':float(2*tp/max(2*tp+fp+fn,1)),
            'tp':int(tp),'fp':int(fp),'fn':int(fn),'fp_per_image':float(fp/len(counts))}

def tune_threshold(pred,rows,cfg):
    grid=np.unique(np.r_[cfg['proposal_conf'],np.linspace(.01,.99,99)])
    values=[operating_metrics(counts_at(pred,rows,float(t)))['f1'] for t in grid]
    # deterministic tie-breaking: smallest threshold, favor recall.
    i=int(np.argmax(values)); return float(grid[i]),float(values[i])

def sync(cfg):
    if cfg['torch_device'].startswith('cuda'): torch.cuda.synchronize()

def benchmark(det,net,rows,alpha,cfg):
    # Decode before timer; include preprocessing, YOLO, NMS, crop, CNN, score transfer.
    ims=[cv2.imread(r['path']) for r in rows[:cfg['benchmark_images']]]
    times={'YOLOv8':[],'YOLOv8+CNN':[]}
    def run(im,hybrid):
        p=predict_yolo(det,im,cfg)
        if hybrid:
            q=cnn_scores(net,im,p['boxes'],cfg); p['scores']=p['scores']*np.maximum(q,1e-8)**alpha
        return p
    for _ in range(3):
        for hybrid in [False,True]: run(ims[0],hybrid)
    for rep in range(cfg['benchmark_repeats']):
        order=[False,True] if rep%2==0 else [True,False]
        for im in ims:
            for hybrid in order:
                sync(cfg); start=time.perf_counter(); run(im,hybrid); sync(cfg)
                times['YOLOv8+CNN' if hybrid else 'YOLOv8'].append((time.perf_counter()-start)*1000)
    return {k:{'mean_ms':float(np.mean(v)),'median_ms':float(np.median(v)),'p95_ms':float(np.percentile(v,95)),
               'fps':float(1000/np.mean(v)),'samples':len(v),'scope':'in-memory single image; disk decoding excluded; FP32'} for k,v in times.items()}

def write_csv(path,rows):
    with open(path,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
def predict_yolo(model,im,cfg):
    from ultralytics.cfg import DEFAULT_CFG_DICT
    precision={'quantize':32} if 'quantize' in DEFAULT_CFG_DICT else {'half':False}
    r=model.predict(im,imgsz=cfg['imgsz'],conf=cfg['proposal_conf'],iou=cfg['nms_iou'],
                    max_det=cfg['max_det'],device=cfg['device'],verbose=False,**precision)[0]
    return {'boxes':r.boxes.xyxy.cpu().numpy(),'scores':r.boxes.conf.cpu().numpy()}

@torch.inference_mode()
def collect(det,net,rows,cfg):
    base=[]; probs=[]
    for i,row in enumerate(rows,1):
        im=cv2.imread(row['path'])
        if im is None: raise ValueError(row['path'])
        p=predict_yolo(det,im,cfg); base.append(p); probs.append(cnn_scores(net,im,p['boxes'],cfg))
        if i%20==0 or i==len(rows): print(f'Validation inference: {i}/{len(rows)}',flush=True)
    return base,probs


def load_json(p): return json.loads(Path(p).read_text())


def check_versions(run_dir,allow_drift):
    import importlib.metadata as metadata
    expected={}
    for line in (run_dir/'pip_freeze.txt').read_text().splitlines():
        if '==' in line:
            k,v=line.split('==',1); expected[k.lower()]=v
    actual={k:metadata.version(k) for k in ['ultralytics','torch','torchvision']}
    mismatch={k:{'old':expected.get(k),'current':v} for k,v in actual.items() if expected.get(k)!=v}
    if mismatch and not allow_drift:
        raise RuntimeError(f'추론 재현을 위해 원 실행 버전이 필요합니다: {mismatch}. 원 Colab 환경을 사용하거나 해당 버전을 설치하세요. '
                           '버전 차이를 허용하는 별도 재평가는 ALLOW_VERSION_DRIFT=True로 명시하고 결과에 기록하세요.')
    return {'expected':{k:expected.get(k) for k in actual},'actual':actual,'mismatch':mismatch}


def validation_rows(source,indices,data_root,eps,old_manifest):
    """Reconstruct exact staged GT; check original and canonical-label hashes."""
    rows=[]
    staged={int(Path(r['path']).stem):r for r in old_manifest if r['split']=='val'}
    for idx in sorted(indices):
        src=source[idx]; p=Path(data_root)/src['relative_path']; label=p.parent.parent/'labels'/(p.stem+'.txt')
        if sha(label)!=src['label_sha256']: raise ValueError(f'학습 후 원본 라벨이 변경되었습니다: {label}')
        im=cv2.imread(str(p))
        if im is None: raise ValueError(f'원본 이미지 읽기 실패: {p}')
        h,w=im.shape[:2]
        pixel=hashlib.sha256(np.asarray(im.shape,dtype=np.int64).tobytes()+im.tobytes()).hexdigest()
        if pixel!=src['pixel_sha256']: raise ValueError(f'학습 후 이미지가 변경되었습니다: {p}')
        canonical=[]
        for line in label.read_text().splitlines():
            if not line.strip(): continue
            v=np.array(list(map(float,line.split())),dtype=np.float64)
            if len(v)!=5 or v[0]!=0 or not np.isfinite(v).all(): raise ValueError(f'라벨 오류: {label}')
            _,x,y,bw,bh=v
            if not (-eps<=x<=1+eps and -eps<=y<=1+eps and 0<bw<=1+eps and 0<bh<=1+eps): raise ValueError(f'좌표 오류: {label}')
            v[1:]=np.clip(v[1:],0,1); _,x,y,bw,bh=v
            box=np.clip([(x-bw/2)*w,(y-bh/2)*h,(x+bw/2)*w,(y+bh/2)*h],[0,0,0,0],[w,h,w,h])
            x1,y1,x2,y2=box
            cv=[0,(x1+x2)/(2*w),(y1+y2)/(2*h),(x2-x1)/w,(y2-y1)/h]
            canonical.append(' '.join(f'{a:.12g}' for a in cv))
        txt='\n'.join(canonical)+'\n' if canonical else ''
        if hashlib.sha256(txt.encode()).hexdigest()!=staged[idx]['label_sha256']:
            raise ValueError(f'기존 staging 라벨을 정확히 재현하지 못했습니다: {label}')
        gt=[]
        for line in canonical:
            _,x,y,bw,bh=map(float,line.split())
            gt.append(np.clip([(x-bw/2)*w,(y-bh/2)*h,(x+bw/2)*w,(y+bh/2)*h],[0,0,0,0],[w,h,w,h]).tolist())
        rows.append({'path':str(p),'gt':np.array(gt,dtype=np.float32).reshape(-1,4),'index':idx})
    return rows


def group_bootstrap(c0,c1,groups,n,seed):
    groups=np.asarray(groups); unique=sorted(set(groups)); rng=np.random.default_rng(seed)
    a=np.array([c0[groups==g].sum(0) for g in unique]); b=np.array([c1[groups==g].sum(0) for g in unique])
    delta=[]
    for _ in range(n):
        ix=rng.integers(0,len(unique),len(unique))
        delta.append(operating_metrics(b[ix])['f1']-operating_metrics(a[ix])['f1'])
    return {'delta_f1':operating_metrics(c1)['f1']-operating_metrics(c0)['f1'],
            'ci95':np.quantile(delta,[.025,.975]).tolist(),'resamples':n,
            'unit':'known group','scope':'descriptive OOF interval; CV training sets overlap, not a significance test'}


def recover(run_root,data_root=None,allow_version_drift=False,remeasure_latency=False,reuse_validation_cache=True):
    root=Path(run_root); original_cfg=load_json(root/'cv_config.json')
    source=load_json(root/'source_manifest.json'); folds=load_json(root/'fold_indices.json')['folds']
    if len(folds)!=5: raise ValueError('Expected five folds')
    data_root=data_root or original_cfg['data_root']
    runs=[]
    for fold in folds:
        options=[p for p in (root/f'fold{fold["fold"]}').glob('week5_*') if (p/'test_predictions.json').is_file()]
        if len(options)!=1: raise ValueError(f'fold{fold["fold"]}: 완료 실행 폴더를 하나로 특정할 수 없습니다: {options}')
        run_dir=options[0]
        for name in ['config.json','dataset_manifest.json','cnn_best.pt','detector/weights/best.pt','pip_freeze.txt']:
            if not (run_dir/name).is_file(): raise FileNotFoundError(run_dir/name)
        versions=check_versions(run_dir,allow_version_drift)
        runs.append((fold,run_dir,versions))
    out=root/f'evaluation_repaired_{time.strftime("%Y%m%d_%H%M%S")}_{time.time_ns()%1000000}'
    out.mkdir(exist_ok=False)
    dump(out/'repair_protocol.json',{'source_run':str(root),'training_repeated':False,'max_det':original_cfg['max_det'],
          'fix':'COCO precision tensor at explicit maxDets; invalid overall AP blocks selection',
          'alpha_selection':'original grid and original inner validation only',
          'outer_predictions':'reuse saved boxes, YOLO scores, CNN probabilities',
          'latency':'remeasured' if remeasure_latency else 'not remeasured; original CSV copied separately',
          'allow_version_drift':allow_version_drift,'reuse_validation_cache':reuse_validation_cache,
          'bbox_policy':'GT strictly positive; finite zero-area predictions kept as unmatched detections; nonfinite/reversed coords fail'})
    import shutil
    if (root/'cv_fold_results.csv').is_file(): shutil.copy2(root/'cv_fold_results.csv',out/'original_results_REFERENCE_ONLY.csv')
    all_results=[]; deltas=[]; oof=[None]*len(source); all_counts=[None]*len(source)
    for fold,run_dir,versions in runs:
        k=fold['fold']; dst=out/f'fold{k}'; dst.mkdir()
        cfg=load_json(run_dir/'config.json'); cfg['device']=0 if torch.cuda.is_available() else 'cpu'
        cfg['torch_device']='cuda:0' if torch.cuda.is_available() else 'cpu'
        print(f'Fold {k}/5: 기존 가중치 로드 → inner val 재추론 → alpha 재선택 → 저장된 outer 예측 재평가',flush=True)
        dump(dst/'environment_comparison.json',versions)
        old_trials=[]
        with open(run_dir/'validation_alpha_trials.csv',newline='',encoding='utf-8-sig') as f: old_trials=list(csv.DictReader(f))
        dump(dst/'previous_selection_audit.json',{'trials':old_trials,'invalid_map_trials':sum(float(r['map'])<0 for r in old_trials),
                                                'previous_settings':load_json(run_dir/'locked_validation_settings.json')})
        vr=validation_rows(source,fold['val'],data_root,original_cfg.get('coordinate_eps',1e-6),load_json(run_dir/'dataset_manifest.json'))
        det=YOLO(str(run_dir/'detector/weights/best.pt'))
        checkpoint=torch.load(run_dir/'cnn_best.pt',map_location=cfg['torch_device'],weights_only=True)
        if checkpoint['crop_size']!=cfg['crop_size']: raise ValueError('CNN input size mismatch')
        net=CropCNN().to(cfg['torch_device']); net.load_state_dict(checkpoint['state_dict']); net.eval()
        dump(dst/'weights_hashes.json',{'yolo':sha(run_dir/'detector/weights/best.pt'),'cnn':sha(run_dir/'cnn_best.pt')})
        vb=vq=None
        if reuse_validation_cache:
            expected_hashes=load_json(dst/'weights_hashes.json')
            # Previous successful or interrupted evaluation runs in this original CV run only.
            for cache_path in sorted(root.glob(f'evaluation_repaired_*/fold{k}/validation_predictions.json'),reverse=True):
                if cache_path.parent==dst: continue
                try:
                    if load_json(cache_path.parent/'weights_hashes.json')!=expected_hashes: continue
                    previous_env=load_json(cache_path.parent/'environment_comparison.json')
                    if previous_env['actual']!=versions['actual']: continue
                    cached=load_json(cache_path)
                    cache_by_id={x['source_index']:x for x in cached}
                    if len(cache_by_id)!=len(vr) or set(cache_by_id)!={r['index'] for r in vr}: continue
                    if any(not np.array_equal(np.array(cache_by_id[r['index']]['gt'],dtype=np.float32).reshape(-1,4),r['gt']) for r in vr): continue
                    vb=[{'boxes':np.array(cache_by_id[r['index']]['boxes'],dtype=np.float32).reshape(-1,4),
                         'scores':np.array(cache_by_id[r['index']]['yolo_scores'],dtype=np.float32)} for r in vr]
                    vq=[np.array(cache_by_id[r['index']]['cnn_probs'],dtype=np.float32) for r in vr]
                    if any(len(p['boxes'])!=len(p['scores']) or len(q)!=len(p['scores']) or not np.isfinite(q).all() or np.any((q<0)|(q>1)) for p,q in zip(vb,vq)):
                        vb=vq=None; continue
                    dump(dst/'validation_cache_source.json',{'path':str(cache_path)})
                    print(f'Validation cache 재사용: {cache_path}',flush=True)
                    break
                except (OSError,ValueError,KeyError,TypeError):
                    vb=vq=None; continue
        if vb is None:
            vb,vq=collect(det,net,vr,cfg)
        dump(dst/'validation_predictions.json',[{'source_index':r['index'],'image':r['path'],'gt':r['gt'].tolist(),
            'boxes':p['boxes'].tolist(),'yolo_scores':p['scores'].tolist(),'cnn_probs':q.tolist()} for r,p,q in zip(vr,vb,vq)])
        trials=[{'alpha':a,**map_metrics(rescore(vb,vq,a),vr,cfg)} for a in cfg['alpha_grid']]
        selected=select_alpha(trials); alpha=selected['alpha']; vh=rescore(vb,vq,alpha)
        t0,f0=tune_threshold(vb,vr,cfg); t1,f1=tune_threshold(vh,vr,cfg)
        write_csv(dst/'validation_alpha_trials.csv',trials)
        dump(dst/'locked_validation_settings.json',{'alpha':alpha,'yolo_threshold':t0,'hybrid_threshold':t1,
             'val_f1':[f0,f1],'val_selected_map':selected['map'],'max_det':cfg['max_det']})
        # Only now read outer-holdout predictions; no outer scores enter alpha selection.
        cache=load_json(run_dir/'test_predictions.json')
        indices=[int(Path(p['image']).stem) for p in cache]
        if sorted(indices)!=sorted(fold['test']): raise ValueError('Outer prediction membership mismatch')
        tb=[{'boxes':np.array(p['boxes'],dtype=np.float32).reshape(-1,4),'scores':np.array(p['yolo_scores'],dtype=np.float32)} for p in cache]
        tq=[np.array(p['cnn_probs'],dtype=np.float32) for p in cache]
        if any(len(q)!=len(p['scores']) or not np.isfinite(q).all() or np.any((q<0)|(q>1)) for p,q in zip(tb,tq)):
            raise ValueError('Invalid cached CNN probabilities')
        tr=[{'path':str(Path(data_root)/source[i]['relative_path']),'gt':np.array(p['gt'],dtype=np.float32).reshape(-1,4)} for i,p in zip(indices,cache)]
        th=rescore(tb,tq,alpha); counts=[]; fold_result=[]
        speed=benchmark(det,net,tr,alpha,cfg) if remeasure_latency else None
        for name,p,t in [('YOLOv8',tb,t0),('YOLOv8+CNN',th,t1)]:
            c=counts_at(p,tr,t); counts.append(c)
            result={'fold':k,'model':name,'threshold':t,'alpha':0. if name=='YOLOv8' else alpha,
                    **map_metrics(p,tr,cfg),**operating_metrics(c)}
            if speed: result.update({key:speed[name][key] for key in ['mean_ms','median_ms','p95_ms','fps','samples']})
            fold_result.append(result); all_results.append(result)
        write_csv(dst/'test_comparison.csv',fold_result)
        write_csv(dst/'test_shared_threshold.csv',[{'model':name,'threshold':cfg['shared_threshold'],
                   **operating_metrics(counts_at(p,tr,cfg['shared_threshold']))} for name,p in [('YOLOv8',tb),('YOLOv8+CNN',th)]])
        per=[]; repaired=[]
        for j,(i,r,p,q,hp) in enumerate(zip(indices,tr,tb,tq,th)):
            rec={'source_index':i,'fold':k,'image':r['path'],'gt':r['gt'].tolist(),'boxes':p['boxes'].tolist(),
                 'yolo_scores':p['scores'].tolist(),'cnn_probs':q.tolist(),'hybrid_scores':hp['scores'].tolist()}
            oof[i]=rec; repaired.append(rec); all_counts[i]=[counts[0][j].tolist(),counts[1][j].tolist()]
            per.append({'source_index':i,'image':r['path'],**{f'{n}_{key}':int(counts[m][j,z]) for m,n in enumerate(['yolo','hybrid']) for z,key in enumerate(['tp','fp','fn'])}})
        write_csv(dst/'test_per_image.csv',per); dump(dst/'test_predictions.json',repaired)
        delta={'fold':k,**{f'delta_{m}':fold_result[1][m]-fold_result[0][m] for m in ['map','map_50','precision','recall','f1','fp_per_image']}}
        deltas.append(delta)
        write_csv(out/'cv_fold_results.csv',all_results); write_csv(out/'cv_paired_fold_deltas.csv',deltas)
        dump(out/'completed_folds.json',{'completed':k,'total':5})
        print(f'Fold {k}: alpha={alpha}, mAP={fold_result[0]["map"]:.4f} → {fold_result[1]["map"]:.4f}',flush=True)
        del det,net
        if torch.cuda.is_available(): torch.cuda.empty_cache()
    if any(p is None for p in oof): raise ValueError('Incomplete OOF coverage')
    dump(out/'oof_predictions.json',oof)
    metrics=['map','map_50','precision','recall','f1','fp_per_image']+(['mean_ms','fps'] if remeasure_latency else [])
    summary=[]
    for name in ['YOLOv8','YOLOv8+CNN']:
        for m in metrics:
            vals=np.array([r[m] for r in all_results if r['model']==name])
            summary.append({'model':name,'metric':m,'mean':float(vals.mean()),'std_ddof1':float(vals.std(ddof=1)),'folds':5})
    write_csv(out/'cv_summary_mean_std.csv',summary)
    cs=np.array(all_counts)
    dump(out/'oof_paired_group_bootstrap_f1.json',group_bootstrap(cs[:,0],cs[:,1],[r['group'] for r in source],original_cfg['bootstrap_n'],original_cfg['seed']))
    import matplotlib.pyplot as plt
    fig,axs=plt.subplots(1,2,figsize=(11,4))
    for name in ['YOLOv8','YOLOv8+CNN']:
        r=[r for r in all_results if r['model']==name]
        for ax,m in zip(axs,['map','f1']): ax.plot([x['fold'] for x in r],[x[m] for x in r],marker='o',label=name)
    for ax,title in zip(axs,['Corrected outer mAP50-95 @300','Outer F1 after validation selection']):
        ax.set_xticks(range(1,6)); ax.set_ylim(0,1); ax.set_xlabel('Fold'); ax.set_title(title); ax.legend()
    fig.tight_layout(); fig.savefig(out/'cv_comparison.png',dpi=180); plt.close(fig)
    print('평가 복구 완료:',out); return out,all_results
