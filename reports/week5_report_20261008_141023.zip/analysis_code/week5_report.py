"""Week 5: frozen outer-fold reporting; never train or tune on outer data."""
from pathlib import Path
import json, time, hashlib, textwrap, platform, importlib.metadata
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from PIL import Image
from week5_coco_fixed import evaluate

MODELS=['YOLOv8','YOLOv8+CNN']
METRICS=['map','map_50','precision','recall','f1','fp_per_image']
LABELS=['mAP50-95','mAP50','Precision','Recall','F1','FP/image']
CASES={'fp_removed':'오탐 제거 성공','tp_lost':'정답 누락 발생','tp_gained':'누락 포트홀 복구','fp_added':'새 오탐 발생','both_miss':'두 방법의 공통 실패'}

def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def dump(p,x): Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def csv(p,x): pd.DataFrame(x).to_csv(p,index=False,encoding='utf-8-sig')
def savefig(fig,p):
    fig.savefig(p,dpi=160,bbox_inches='tight'); plt.close(fig)
def setup_font():
    from matplotlib import font_manager
    for p in [str(Path(__file__).with_name('NanumGothic.ttf')), '/usr/share/fonts/truetype/nanum/NanumGothic.ttf','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc']:
        if Path(p).exists():
            font_manager.fontManager.addfont(p); plt.rcParams['font.family']=font_manager.FontProperties(fname=p).get_name(); break
    plt.rcParams['axes.unicode_minus']=False

def ious(a,b):
    a=np.asarray(a,float).reshape(-1,4); b=np.asarray(b,float).reshape(-1,4)
    inter=np.maximum(np.minimum(a[:,None,2:],b[None,:,2:])-np.maximum(a[:,None,:2],b[None,:,:2]),0).prod(2)
    return inter/np.maximum(np.maximum(a[:,2:]-a[:,:2],0).prod(1)[:,None]+np.maximum(b[:,2:]-b[:,:2],0).prod(1)[None,:]-inter,1e-9)

def match(boxes,scores,gt,threshold):
    scores=np.asarray(scores); idx=np.flatnonzero(scores>=threshold)
    idx=idx[np.argsort(-scores[idx],kind='stable')]; ov=ious(boxes,gt); pairs={}; used=set(); fp=[]
    for i in idx:
        eligible=[j for j in range(len(gt)) if j not in used and ov[i,j]>=.5]
        if eligible:
            j=max(eligible,key=lambda j:ov[i,j]); pairs[int(i)]=j; used.add(j)
        else: fp.append(int(i))
    return {'pairs':pairs,'fp':fp,'fn':sorted(set(range(len(gt)))-used),'kept':idx.tolist()}

def counts(m): return [len(m['pairs']),len(m['fp']),len(m['fn'])]
def op(c):
    tp,fp,fn=np.asarray(c).sum(0)
    return dict(tp=int(tp),fp=int(fp),fn=int(fn),precision=float(tp/max(tp+fp,1)),recall=float(tp/max(tp+fn,1)),f1=float(2*tp/max(2*tp+fp+fn,1)),fp_per_image=float(fp/len(c)))

def load_report(run_root,eval_dir,data_root,output=None):
    root=Path(run_root); ed=Path(eval_dir)
    if not root.is_dir() or not ed.is_dir(): raise FileNotFoundError(f'RUN_ROOT={root}\nEVAL_DIR={ed}')
    records=read(ed/'oof_predictions.json'); source=read(root/'source_manifest.json')
    foldspec=read(root/'fold_indices.json')['folds']
    if len(foldspec)!=5 or {x['fold'] for x in records}!={1,2,3,4,5}: raise ValueError('5 folds required')
    ids=[r['source_index'] for r in records]
    if len(ids)!=len(set(ids)) or set(ids)!=set(range(len(source))): raise ValueError('OOF coverage mismatch')
    settings={}; configs={}; runs={}
    for fs in foldspec:
        k=fs['fold']
        if {r['source_index'] for r in records if r['fold']==k}!=set(fs['test']): raise ValueError(f'fold{k}: membership mismatch')
        settings[k]=read(ed/f'fold{k}/locked_validation_settings.json')
        options=[p for p in (root/f'fold{k}').glob('week5_*') if (p/'test_predictions.json').is_file()]
        if len(options)!=1: raise ValueError(f'fold{k}: expected one original run, found {options}')
        runs[k]=options[0]; configs[k]=read(options[0]/'config.json')
    for r in records:
        k=r['fold']; s=settings[k]; r['image']=str(Path(data_root)/source[r['source_index']]['relative_path'])
        for field in ['gt','boxes']: r[field]=np.array(r[field],np.float32).reshape(-1,4)
        for field in ['yolo_scores','cnn_probs','hybrid_scores']: r[field]=np.array(r[field],np.float32)
        if any(len(r[f])!=len(r['boxes']) for f in ['yolo_scores','cnn_probs','hybrid_scores']): raise ValueError('Misaligned predictions')
        if not np.isfinite(r['cnn_probs']).all() or np.any((r['cnn_probs']<0)|(r['cnn_probs']>1)): raise ValueError('Invalid CNN probability')
        expected=r['yolo_scores']*np.maximum(r['cnn_probs'],1e-8)**s['alpha']
        if not np.allclose(expected,r['hybrid_scores'],rtol=1e-5,atol=1e-7): raise ValueError('Saved alpha/scores mismatch')
    out=Path(output) if output else ed/('week5_report_'+time.strftime('%Y%m%d_%H%M%S'))
    out.mkdir(parents=True,exist_ok=False)
    for d in ['graphs','cases','speed']: (out/d).mkdir()
    dump(out/'protocol.json',{'run_root':str(root),'evaluation':str(ed),'operating_iou':.5,'training':False,'outer_tuning':False,'case_reason':'score/IoU/threshold evidence; visual causes require human review'})
    return dict(root=root,ed=ed,out=out,records=records,source=source,settings=settings,configs=configs,runs=runs)

def make_tables_graphs(ctx):
    setup_font(); out=ctx['out']; rows=[]; prs=[]; image_rows=[]
    for k in range(1,6):
        rr=[r for r in ctx['records'] if r['fold']==k]; s=ctx['settings'][k]
        for model,field,th in [(MODELS[0],'yolo_scores',s['yolo_threshold']),(MODELS[1],'hybrid_scores',s['hybrid_threshold'])]:
            pred=[dict(boxes=r['boxes'],scores=r[field]) for r in rr]
            metrics,ev=evaluate(pred,rr,int(ctx['configs'][k]['max_det']))
            cc=[counts(match(r['boxes'],r[field],r['gt'],th)) for r in rr]
            rows.append(dict(fold=k,model=model,threshold=th,alpha=0 if model==MODELS[0] else s['alpha'],**metrics,**op(cc)))
            for r,c in zip(rr,cc): image_rows.append(dict(fold=k,source_index=r['source_index'],model=model,tp=c[0],fp=c[1],fn=c[2]))
            precision=ev.eval['precision'][0,:,0,0,-1]
            for recall,p in zip(ev.params.recThrs,precision):
                prs.append(dict(fold=k,model=model,recall=float(recall),precision=float(p)))
        print(f'표/COCO PR 검증 완료: Fold {k}/5',flush=True)
    df=pd.DataFrame(rows); old=pd.read_csv(ctx['ed']/'cv_fold_results.csv')
    joined=df.merge(old,on=['fold','model'],suffixes=('_new','_saved'),validate='one_to_one')
    if len(joined)!=10: raise ValueError('Saved result must contain both models for all 5 folds')
    for m in METRICS+['tp','fp','fn']:
        if not np.allclose(joined[m+'_new'],joined[m+'_saved'],atol=2e-6): raise ValueError(f'Recomputed {m} differs from recovery result')
    csv(out/'fold_results.csv',rows); csv(out/'per_image_counts.csv',image_rows); csv(out/'pr_curves.csv',prs)
    summary=df.groupby('model')[METRICS].agg(['mean','std']).reindex(MODELS)
    summary.to_csv(out/'mean_std.csv',encoding='utf-8-sig')
    delta=df.pivot(index='fold',columns='model',values=METRICS)
    pd.DataFrame({m:delta[m][MODELS[1]]-delta[m][MODELS[0]] for m in METRICS}).to_csv(out/'paired_deltas.csv',encoding='utf-8-sig')
    fig,axes=plt.subplots(2,3,figsize=(14,8))
    for ax,m,label in zip(axes.flat,METRICS,LABELS):
        for name in MODELS:
            z=df[df.model==name]; ax.plot(z.fold,z[m],'-o',label=name)
        ax.set(title=label,xlabel='Outer fold',xticks=range(1,6)); ax.grid(alpha=.25)
    axes.flat[0].legend(); fig.tight_layout(); savefig(fig,out/'graphs/fold_metrics.png')
    fig,axes=plt.subplots(2,3,figsize=(14,8))
    for ax,m,label in zip(axes.flat,METRICS,LABELS):
        ax.bar(MODELS,summary[(m,'mean')],yerr=summary[(m,'std')],capsize=5,color=['#377eb8','#ff7f00']); ax.set_title(label); ax.set_ylim(bottom=0)
    fig.suptitle('5-fold mean ± sample SD (not a confidence interval)'); fig.tight_layout(); savefig(fig,out/'graphs/mean_std.png')
    pr=pd.DataFrame(prs); fig,axes=plt.subplots(2,3,figsize=(14,8))
    for k,ax in enumerate(axes.flat[:5],1):
        for name in MODELS:
            z=pr[(pr.fold==k)&(pr.model==name)]; ax.plot(z.recall,z.precision,label=name)
            row=df[(df.fold==k)&(df.model==name)].iloc[0]; ax.scatter(row.recall,row.precision,s=28,color=ax.lines[-1].get_color())
        ax.set(title=f'Fold {k}: COCO interpolated PR@0.5',xlabel='Recall',ylabel='Precision',xlim=(0,1),ylim=(0,1.02)); ax.grid(alpha=.2)
    ax=axes.flat[5]
    for name in MODELS:
        z=pr[pr.model==name].groupby('recall').precision.agg(['mean','std']); ax.plot(z.index,z['mean'],label=name); ax.fill_between(z.index,(z['mean']-z['std']).clip(0,1),(z['mean']+z['std']).clip(0,1),alpha=.15)
    ax.set(title='Macro fold PR: mean ± SD',xlabel='Recall',ylabel='Precision',xlim=(0,1),ylim=(0,1.02)); ax.legend(); fig.tight_layout(); savefig(fig,out/'graphs/pr_curves.png')
    ctx['results']=df; return df,summary

def case_events(r,s):
    a=match(r['boxes'],r['yolo_scores'],r['gt'],s['yolo_threshold']); b=match(r['boxes'],r['hybrid_scores'],r['gt'],s['hybrid_threshold'])
    found=[]; ag=set(a['pairs'].values()); bg=set(b['pairs'].values())
    for i in sorted(set(a['fp'])-set(b['kept'])): found.append(('fp_removed',i,None))
    for j in sorted(ag-bg): found.append(('tp_lost',next(i for i,g in a['pairs'].items() if g==j),j))
    for j in sorted(bg-ag): found.append(('tp_gained',next(i for i,g in b['pairs'].items() if g==j),j))
    for i in sorted(set(b['fp'])-set(a['kept'])): found.append(('fp_added',i,None))
    for j in sorted(set(a['fn'])&set(b['fn'])):
        ov=ious(r['boxes'],r['gt'])[:,j]; found.append(('both_miss',int(np.argmax(ov)) if len(ov) else None,j))
    return a,b,found

def reason(r,s,kind,i,j):
    if i is None: return '저장된 YOLO 후보가 없어 두 방법 모두 이 GT를 검출하지 못함. 후보 생성 이전의 원인은 추가 검토 필요.'
    y=float(r['yolo_scores'][i]); h=float(r['hybrid_scores'][i]); q=float(r['cnn_probs'][i]); ov=ious(r['boxes'][i:i+1],r['gt'])[0]
    best=float(ov.max()) if len(ov) else 0.
    details=f'후보 #{i}: YOLO={y:.3f}, CNN P={q:.3f}, 결합={h:.3f}; 임계값 YOLO={s["yolo_threshold"]:.2f}/결합={s["hybrid_threshold"]:.2f}; 최대 GT IoU={best:.3f}.'
    details+=f' YOLO 통과={y>=s["yolo_threshold"]}, 결합 통과={h>=s["hybrid_threshold"]}.'
    statements={
      'fp_removed':'YOLO의 미매칭 후보가 결합 점수/임계값 조건에서 제외됨. 라벨 기준 오탐 제거 성공.',
      'tp_lost':'YOLO에서 매칭된 GT가 결합 결과에서는 미매칭. 점수 필터 또는 점수 순서에 따른 매칭 변화로 정답 누락.',
      'tp_gained':'기존 후보가 결합 결과에서 GT와 매칭됨. 임계값/순위 변경의 효과이며 새 박스 생성은 아님.',
      'fp_added':'YOLO에서 제외된 후보가 결합 임계값을 통과했으나 GT와 미매칭. 낮아진 임계값에 따른 오탐 유입.',
      'both_miss':'두 결과 모두 이 GT와 매칭되지 않음.'}
    extra=''
    if kind=='both_miss':
        bestgt=float(ious(r['boxes'][i:i+1],r['gt'][j:j+1])[0,0])
        extra=f' 해당 GT와 후보 최대 IoU={bestgt:.3f}. '+('저장된 후보 중 IoU 0.5 이상이 없음: 위치/후보 커버리지 실패.' if bestgt<.5 else '겹치는 후보는 존재: 임계값 필터 또는 일대일 매칭 경쟁 확인 필요.')
    if j is not None:
        w,hg=r['gt'][j,2:]-r['gt'][j,:2]; extra+=f' GT 크기={w:.1f}×{hg:.1f}px.'
    return details+' '+statements[kind]+extra

def image_verified(ctx,r):
    # Use the same decoder as the training manifest before trusting overlays.
    import cv2
    im=cv2.imread(r['image'])
    if im is None: raise FileNotFoundError(r['image'])
    src=ctx['source'][r['source_index']]
    digest=hashlib.sha256(np.asarray(im.shape,dtype=np.int64).tobytes()+im.tobytes()).hexdigest()
    if digest!=src['pixel_sha256']: raise ValueError(f'Image changed after training: {r["image"]}')
    return cv2.cvtColor(im,cv2.COLOR_BGR2RGB)

def make_cases(ctx,per_case=3,seed=20261008,manual_notes=None):
    setup_font(); pool={k:[] for k in CASES}; notes=manual_notes or {}; out=ctx['out']; all_rows=[]
    for r in sorted(ctx['records'],key=lambda r:r['source_index']):
        a,b,events=case_events(r,ctx['settings'][r['fold']])
        # One event of each type per image; avoid images with many boxes dominating selection.
        seen=set()
        for kind,i,j in events:
            if kind not in seen: pool[kind].append((r,a,b,i,j)); seen.add(kind)
    rng=np.random.default_rng(seed); status=[]; used=set()
    for kind,items in pool.items():
        order=rng.permutation(len(items)); chosen=[]
        for ix in order:
            entry=items[ix]
            if entry[0]['source_index'] not in used: chosen.append(entry); used.add(entry[0]['source_index'])
            if len(chosen)==per_case: break
        # Allow cross-category reuse only if needed; never fabricate a missing category.
        if len(chosen)<min(per_case,len(items)):
            have={x[0]['source_index'] for x in chosen}
            chosen += [items[ix] for ix in order if items[ix][0]['source_index'] not in have][:per_case-len(chosen)]
        status.append(dict(case=kind,title=CASES[kind],eligible_images=len(items),shown=len(chosen)))
        if not chosen:
            fig,ax=plt.subplots(figsize=(12,3)); ax.axis('off'); ax.text(.05,.5,CASES[kind]+'\n해당 조건의 사례 없음: 다른 사례로 대체하거나 조작하지 않음.',fontsize=16); savefig(fig,out/f'cases/{kind}_NONE.png')
        for n,(r,a,b,i,j) in enumerate(chosen,1):
            s=ctx['settings'][r['fold']]; im=image_verified(ctx,r); explain=reason(r,s,kind,i,j)
            note=notes.get(str(r['source_index']),'미검토: 그림자·균열·흐림 등 시각적 원인은 이미지 직접 확인 후 기록')
            fig,axes=plt.subplots(1,3,figsize=(18,6.5)); fig.subplots_adjust(bottom=.28,top=.86,wspace=.05)
            for ax in axes: ax.imshow(im); ax.axis('off'); ax.set_anchor('N')
            axes[0].set_title('GT / 정답 라벨 (blue)')
            for g,box in enumerate(r['gt']): draw_box(axes[0],box,'#00bfff',f'GT{g}',4 if g==j else 2)
            for ax,m,field,title in [(axes[1],a,'yolo_scores','YOLOv8'),(axes[2],b,'hybrid_scores','YOLOv8+CNN')]:
                ax.set_title(f'{title}: TP={len(m["pairs"])} FP={len(m["fp"])} FN={len(m["fn"])}')
                for g in m['fn']: draw_box(ax,r['gt'][g],'#00bfff',f'FN GT{g}',2,':')
                for idx in m['kept']:
                    tp=idx in m['pairs']; draw_box(ax,r['boxes'][idx],'#00dd55' if tp else '#ff3344',f'#{idx} {"TP" if tp else "FP"} {r[field][idx]:.2f}',3)
                if i is not None: draw_box(ax,r['boxes'][i],'#ffc000',f'FOCUS #{i}',3,'--')
            fig.suptitle(f'{CASES[kind]} | fold {r["fold"]} | source {r["source_index"]}',fontsize=17)
            caption='관측 근거: '+explain+'\n사람 검토: '+note+'\n범례: 초록 TP / 빨강 FP / 파랑 GT·FN / 노랑 분석 대상(제외된 후보도 표시). IoU ≥ 0.5 일대일 매칭.'
            fig.text(.025,.02,'\n'.join(textwrap.fill(line,110) for line in caption.split('\n')),fontsize=11,va='bottom')
            path=out/f'cases/{kind}_{n:02d}_fold{r["fold"]}_src{r["source_index"]}.png'; savefig(fig,path)
            all_rows.append(dict(case=kind,fold=r['fold'],source_index=r['source_index'],image=r['image'],candidate_index=i,gt_index=j,reason=explain,human_note=note,output=str(path)))
    csv(out/'case_selection.csv',all_rows); csv(out/'case_availability.csv',status)
    dump(out/'manual_notes_template.json',{str(r['source_index']):notes.get(str(r['source_index']),'') for r in all_rows})
    return pd.DataFrame(status)

def draw_box(ax,b,color,label,width=2,style='-'):
    x,y,x2,y2=map(float,b); ax.add_patch(Rectangle((x,y),x2-x,y2-y,fill=False,edgecolor=color,linewidth=width,linestyle=style)); ax.text(x,y2 if style=='--' else y,label,color='white',fontsize=8,bbox=dict(facecolor=color,alpha=.75,pad=1))

PAPER=[dict(paper='Wang et al., YOLOv10 (2024), Table 1',model=m,latency_ms=t,forward_ms=f,hardware='NVIDIA T4',backend='TensorRT FP16',dataset='COCO',source='https://arxiv.org/html/2405.14458v1',note='Literature reference only; not directly comparable with this PyTorch pothole pipeline') for m,t,f in [('YOLOv8-N',6.16,1.77),('YOLOv8-S',7.07,2.33),('YOLOv8-M',9.50,5.09)]]

def benchmark_all(ctx,images_per_fold=30,repeats=3,warmup=10,seed=20261008,full_accuracy=True,allow_version_drift=False):
    import torch,cv2,traceback
    from ultralytics import YOLO
    from ultralytics.cfg import DEFAULT_CFG_DICT
    from week5_recovery import CropCNN,crop_tensor,sha
    out=ctx['out']/'speed'; raw=[]; results=[]; accuracy=[]; statuses=[]
    versions={x:importlib.metadata.version(x) for x in ['torch','torchvision','ultralytics','numpy','pycocotools']}
    versions['opencv']=cv2.__version__
    gpu=torch.cuda.is_available(); device='cuda:0' if gpu else 'cpu'
    torch.backends.cuda.matmul.allow_tf32=False; torch.backends.cudnn.allow_tf32=False
    if min(images_per_fold,repeats,warmup)<1: raise ValueError('Positive benchmark counts required')
    env=dict(versions=versions,python=platform.python_version(),device=torch.cuda.get_device_name(0) if gpu else platform.processor(),cuda=torch.version.cuda,cudnn=torch.backends.cudnn.version(),cpu_threads=torch.get_num_threads(),tf32=False,batch=1,rect=True,scope='Decoded RAM image -> preprocessing + YOLO + NMS + CPU box transfer + optional crop/CNN + score/filter; excludes disk/decode/draw',alpha_zero='CNN still executed to measure architecture cost',warmup=warmup,repeats=repeats,images_per_fold=images_per_fold,seed=seed,full_accuracy=full_accuracy)
    dump(out/'environment.json',env); csv(out/'paper_reference_ONLY.csv',PAPER)
    def sync():
        if gpu: torch.cuda.synchronize()
    for k in range(1,6):
        run=ctx['runs'][k]; saved_env=read(ctx['ed']/f'fold{k}/environment_comparison.json')['actual']
        drift={x:[saved_env.get(x),versions[x]] for x in ['torch','torchvision','ultralytics'] if saved_env.get(x)!=versions[x]}
        if drift and not allow_version_drift: raise RuntimeError(f'Fold{k} environment differs from recovered evaluation: {drift}. Restore versions or explicitly set ALLOW_VERSION_DRIFT=True.')
        hashes=read(ctx['ed']/f'fold{k}/weights_hashes.json')
        if sha(run/'detector/weights/best.pt')!=hashes['yolo'] or sha(run/'cnn_best.pt')!=hashes['cnn']: raise ValueError('Weights changed since recovered evaluation')
        cfg=ctx['configs'][k]; s=ctx['settings'][k]; rr=sorted([r for r in ctx['records'] if r['fold']==k],key=lambda r:r['source_index'])
        ix=np.random.default_rng(seed+k).choice(len(rr),min(images_per_fold,len(rr)),replace=False)
        selected=[rr[i] for i in ix]; ims=[cv2.cvtColor(image_verified(ctx,r),cv2.COLOR_RGB2BGR) for r in selected]
        dump(out/f'fold{k}_sample.json',dict(source_indices=[r['source_index'] for r in selected],weights=hashes,version_drift=drift))
        cases=[('A_original_FP32',int(cfg['imgsz']),32),('B_640_FP32',640,32),('C_640_FP16',640,16)]
        for case,size,bits in cases:
            if bits==16 and not gpu:
                statuses.append(dict(fold=k,case=case,status='SKIPPED',reason='FP16 scenario requires CUDA; no FP32 fallback')); csv(out/'status.csv',statuses); print(f'Fold{k} {case}: CUDA 없음 → SKIPPED',flush=True); continue
            det=net=None
            try:
                det=YOLO(str(run/'detector/weights/best.pt'))
                ck=torch.load(run/'cnn_best.pt',map_location='cpu',weights_only=True)
                if ck['crop_size']!=cfg['crop_size']: raise ValueError('CNN crop size mismatch')
                net=CropCNN().to(device); net.load_state_dict(ck['state_dict']); net.eval()
                if bits==16: net.half()
                precision={'quantize':bits} if 'quantize' in DEFAULT_CFG_DICT else {'half':bits==16}
                @torch.inference_mode()
                def infer(im,hybrid):
                    res=det.predict(im,imgsz=size,conf=cfg['proposal_conf'],iou=cfg['nms_iou'],max_det=cfg['max_det'],device=0 if gpu else 'cpu',rect=True,verbose=False,**precision)[0]
                    boxes=res.boxes.xyxy.float().cpu().numpy(); ys=res.boxes.conf.float().cpu().numpy(); scores=ys.copy()
                    if hybrid:
                        qs=[]
                        for start in range(0,len(boxes),cfg['cnn_batch']):
                            x=torch.stack([crop_tensor(im,b,cfg['crop_size']) for b in boxes[start:start+cfg['cnn_batch']]])
                            x=x.to(device=device,dtype=next(net.parameters()).dtype)
                            qs.append(net(x).sigmoid().float().cpu().numpy())
                        q=np.concatenate(qs) if qs else np.empty(0,np.float32)
                        scores=ys*np.maximum(q,1e-8)**s['alpha']
                    th=s['hybrid_threshold'] if hybrid else s['yolo_threshold']; keep=scores>=th
                    return dict(boxes=boxes,scores=scores,yolo_scores=ys,final_boxes=boxes[keep],final_scores=scores[keep])
                print(f'속도 Fold{k}/5 {case}: imgsz={size}, FP{bits}, batch=1, 표본={len(ims)}',flush=True)
                for n in range(warmup):
                    infer(ims[n%len(ims)],False); infer(ims[n%len(ims)],True)
                actual_dtype=str(next(det.predictor.model.model.parameters()).dtype)
                expected='torch.float16' if bits==16 else 'torch.float32'
                if actual_dtype!=expected: raise RuntimeError(f'Requested {expected}, actual detector {actual_dtype}; refusing mislabeled speed results')
                local=[]
                for rep in range(repeats):
                    for z,im in enumerate(ims):
                        order=[False,True] if (rep+z)%2==0 else [True,False]
                        for hybrid in order:
                            sync(); start=time.perf_counter(); p=infer(im,hybrid); sync(); elapsed=(time.perf_counter()-start)*1000
                            local.append(dict(fold=k,case=case,model=MODELS[int(hybrid)],imgsz=size,precision=f'FP{bits}',source_index=selected[z]['source_index'],repeat=rep,ms=elapsed,candidates=len(p['boxes']),final_detections=len(p['final_boxes']),alpha=s['alpha']))
                raw.extend(local); csv(out/'raw_latency.csv',raw)
                for name in MODELS:
                    values=np.array([x['ms'] for x in local if x['model']==name]); nc=[x['candidates'] for x in local if x['model']==name]
                    results.append(dict(fold=k,case=case,model=name,imgsz=size,precision=f'FP{bits}',mean_ms=float(values.mean()),median_ms=float(np.median(values)),p95_ms=float(np.percentile(values,95)),fps=float(1000/values.mean()),samples=len(values),unique_images=len(ims),mean_candidates=float(np.mean(nc))))
                csv(out/'fold_latency.csv',results)
                if full_accuracy:
                    base=[]; hybridpred=[]
                    for n,r in enumerate(rr,1):
                        im=cv2.cvtColor(image_verified(ctx,r),cv2.COLOR_RGB2BGR); p=infer(im,True)
                        base.append(dict(boxes=p['boxes'],scores=p['yolo_scores'])); hybridpred.append(dict(boxes=p['boxes'],scores=p['scores']))
                        if n%30==0 or n==len(rr): print(f'  {case} outer 정확도: {n}/{len(rr)}',flush=True)
                    for name,pred,th in [(MODELS[0],base,s['yolo_threshold']),(MODELS[1],hybridpred,s['hybrid_threshold'])]:
                        met,_=evaluate(pred,rr,int(cfg['max_det'])); cc=[counts(match(p['boxes'],p['scores'],r['gt'],th)) for p,r in zip(pred,rr)]
                        accuracy.append(dict(fold=k,case=case,model=name,threshold=th,alpha=s['alpha'] if name==MODELS[1] else 0,**met,**op(cc)))
                    csv(out/'scenario_accuracy.csv',accuracy)
                statuses.append(dict(fold=k,case=case,status='OK',reason=''))
            except Exception as exc:
                statuses.append(dict(fold=k,case=case,status='FAILED',reason=repr(exc))); (out/f'fold{k}_{case}_error.txt').write_text(traceback.format_exc()); print(f'실패: Fold{k} {case}: {exc}',flush=True)
            finally:
                csv(out/'status.csv',statuses)
                del det,net
                if gpu: torch.cuda.empty_cache()
    if results:
        df=pd.DataFrame(results); agg=df.groupby(['case','model'])[['mean_ms','p95_ms','fps','mean_candidates']].agg(['mean','std']); agg.to_csv(out/'latency_mean_std.csv',encoding='utf-8-sig')
        fig,axes=plt.subplots(1,2,figsize=(13,5))
        for ax,metric in zip(axes,['mean_ms','fps']):
            keys=list(dict.fromkeys(df.case)); x=np.arange(len(keys))
            for j,name in enumerate(MODELS):
                g=df[df.model==name].groupby('case')[metric].agg(['mean','std']).reindex(keys)
                ax.bar(x+(j-.5)*.36,g['mean'],.36,yerr=g['std'],capsize=4,label=name)
            ax.set_xticks(x,keys,rotation=12); ax.set_ylabel(metric); ax.legend(); ax.set_ylim(bottom=0)
        fig.suptitle('Measured PyTorch pipeline: fold mean ± SD'); fig.tight_layout(); savefig(fig,out/'speed_comparison.png')
    else: df=pd.DataFrame()
    return df,pd.DataFrame(accuracy),pd.DataFrame(statuses)

def make_index(ctx):
    import html
    out=ctx['out']; blocks=['<!doctype html><meta charset="utf-8"><title>Week 5 report</title><style>body{font-family:sans-serif;max-width:1400px;margin:30px auto}img{width:100%}table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:7px}</style><h1>Week 5: YOLOv8 vs YOLOv8+CNN</h1>','<p>5-fold outer 평가 / inner validation에서 동결한 alpha·임계값. 사례는 진단용이며 개선 효과의 대표성 또는 원인 인과관계를 증명하지 않습니다.</p>']
    for p in [out/'fold_results.csv',out/'case_availability.csv',out/'speed/status.csv',out/'speed/fold_latency.csv',out/'speed/scenario_accuracy.csv',out/'speed/paper_reference_ONLY.csv']:
        if p.exists(): blocks += [f'<h2>{p.name}</h2>',pd.read_csv(p).to_html(index=False,escape=True)]
    for p in list((out/'graphs').glob('*.png'))+list((out/'cases').glob('*.png'))+list((out/'speed').glob('*.png')):
        blocks.append(f'<h2>{html.escape(p.stem)}</h2><img src="{p.relative_to(out).as_posix()}">')
    (out/'index.html').write_text('\n'.join(blocks),encoding='utf-8')
    return out/'index.html'
